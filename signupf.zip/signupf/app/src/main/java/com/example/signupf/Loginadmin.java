package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Loginadmin extends AppCompatActivity {
    Button b3;
    Button b8;
    TextView b9;
    TextInputEditText email,password;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginadmin);
        b3 = (Button) findViewById(R.id.sign);
        b8 = (Button) findViewById(R.id.loginbt);
        b9 = (TextView) findViewById(R.id.forgot_pass);
        email=findViewById(R.id.emailorgggg);
        password=findViewById(R.id.passorgggggg);
        firebaseAuth=FirebaseAuth.getInstance();
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(Loginadmin.this, Signuporg.class);
                startActivity(intent2);
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Email = email.getText().toString();
                String Password = password.getText().toString();
                if (TextUtils.isEmpty(Email)) {
                    Toast.makeText(Loginadmin.this, "Please enter email", Toast.LENGTH_SHORT).show();

                }
                if (TextUtils.isEmpty(Password)) {
                    Toast.makeText(Loginadmin.this, "Please enter password", Toast.LENGTH_SHORT).show();
                    return;

                }
                if (password.length() <= 4) {
                    Toast.makeText(Loginadmin.this, "Password too short", Toast.LENGTH_SHORT).show();
                    return;
                }
                firebaseAuth.signInWithEmailAndPassword(Email, Password)
                        .addOnCompleteListener(Loginadmin.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent int1 = new Intent(Loginadmin.this,Menuorg.class);
                                    startActivity(int1);

                                } else {
                                    Toast.makeText(Loginadmin.this, "Login failed", Toast.LENGTH_SHORT).show();
                                }

                                // ...
                            }
                        });
            }
        });
          b9.setOnClickListener(new View.OnClickListener() {
        @Override
          public void onClick(View view) {
        Intent intent9=new Intent(Loginadmin.this,Forgotadmin.class);
         startActivity(intent9);
         }
         });
    }
}


