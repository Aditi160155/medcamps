package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

public class Accountorg extends AppCompatActivity {
    Button log;
    Button hel;
    Button his;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountorg);
        log=(Button)findViewById(R.id.logout);
        hel=(Button)findViewById(R.id.help1);
        his=(Button)findViewById(R.id.historyy);

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1=new Intent(Accountorg.this,Firstpage.class);
                startActivity(int1);
            }
        });
        hel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2=new Intent(Accountorg.this,Helporg.class);
                startActivity(int2);
            }
        });
        his.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int3=new Intent(Accountorg.this,Historyorg.class);
                startActivity(int3);
            }
        });

    }
}

