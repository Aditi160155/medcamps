package com.example.signupf;


    public class dataholder {
        String Hospitalname,contact,password,email,pimage;

        public dataholder(String hospitalname, String contact, String email) {
            
        }

        public String getHospitalname() {
            return Hospitalname;
        }

        public void setHospitalname(String hospitalname) {
            Hospitalname = hospitalname;
        }

        public String getContact() {
            return contact;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPimage() {
            return pimage;
        }

        public void setPimage(String pimage) {
            this.pimage = pimage;
        }

        public dataholder(String hospitalname, String contact, String password, String email, String pimage) {
            Hospitalname = hospitalname;
            this.contact = contact;
            this.password = password;
            this.email = email;
            this.pimage = pimage;
        }
    }




