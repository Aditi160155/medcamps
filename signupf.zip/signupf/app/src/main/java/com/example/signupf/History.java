package com.example.signupf;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

import java.util.ArrayList;

public class History extends AppCompatActivity {
    SearchView MySearchView;
    ListView myList;

    ArrayList<String> list;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        MySearchView = (SearchView)findViewById(R.id.searchView);
        myList = (ListView)findViewById(R.id.myList);

        list=new ArrayList<String>();

        list.add("Blood Camp");
        list.add("Medical and Health Camp");
        list.add("Free Family Health  Camp");
        list.add("Child Health Camp");
        list.add("Fitness Camp");
        list.add("Post and pre Pregnancy Camps");
        list.add("NGO Camps");
        list.add("Stress management Camps");
        list.add("Healthy heart Checking Camp");
        list.add("Health Camp for Incurable Disease");
        list.add("COVID-19 Awareness Camp");
        list.add("Free Urology Camp");
        list.add("Bone Densitometer Camp");
        list.add("Free Cataract Screening Camp");





        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,list);

        myList.setAdapter(adapter);


        MySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                adapter.getFilter().filter(s);


                return false;
            }
        });
    }
}

