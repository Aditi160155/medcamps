package com.example.signupf;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.InputStream;
import java.util.Random;

public  class Signupffff extends AppCompatActivity {
    private TextInputEditText txt_passs;
    private TextInputEditText txt_user;
    private TextInputEditText txt_email,txt_phone,txt_fname,txt_lname;




    Button register;
    RadioButton male;
    RadioButton female;
    String gender="";
    FirebaseDatabase database;
    DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_i_g_n_u_p_f_f_f_f);
        register = (Button) findViewById(R.id.button);
        txt_passs = findViewById(R.id.finalpass);
        txt_user =  findViewById(R.id.userfinal);
        txt_email =findViewById(R.id.heyemail);
        txt_lname = findViewById(R.id.lstname);
        txt_fname = findViewById(R.id.fstname);
        txt_phone = findViewById(R.id.phonenumber);
        male=findViewById(R.id.radio_male);
        female=findViewById(R.id.radio_female);








        databaseReference = FirebaseDatabase.getInstance().getReference("Student");
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseStorage storage=FirebaseStorage.getInstance();



          register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final String Email = txt_email.getText().toString();
                String password = txt_passs.getText().toString();
                 final String Username =txt_user.getText().toString();
                 final String fullName = txt_fname.getText().toString();
                 final String LastName = txt_lname.getText().toString();
                 final String phonenumber = txt_phone.getText().toString();

                if(male.isChecked()){
                     gender="Male";
                 }
                if(female.isChecked()){
                    gender="Female";
                }



                if (TextUtils.isEmpty(Email)) {
                    Toast.makeText(Signupffff.this, "Please enter email", Toast.LENGTH_SHORT).show();

                }
               if (TextUtils.isEmpty(password)) {
                    Toast.makeText(Signupffff.this, "Please enter password", Toast.LENGTH_SHORT).show();

                }

               if (TextUtils.isEmpty(Username)) {
                    Toast.makeText(Signupffff.this, "Please enter username", Toast.LENGTH_SHORT).show();

                }
               if (TextUtils.isEmpty(fullName)) {
                    Toast.makeText(Signupffff.this, "Please enter Firstname", Toast.LENGTH_SHORT).show();

                }
                if (TextUtils.isEmpty(LastName)) {
                    Toast.makeText(Signupffff.this, "Please enter Lastname", Toast.LENGTH_SHORT).show();

                }
                 if (TextUtils.isEmpty(phonenumber)) {
                    Toast.makeText(Signupffff.this, "Please enter Phonenumber", Toast.LENGTH_SHORT).show();

                }

                if (password.length() <= 4) {
                    Toast.makeText(Signupffff.this, "Password too short", Toast.LENGTH_SHORT).show();

                }
                if (phonenumber.length() <10) {
                    Toast.makeText(Signupffff.this, "Invalid Phonenumber", Toast.LENGTH_SHORT).show();

                }


                firebaseAuth.createUserWithEmailAndPassword(Email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                       @Override
                       public void onComplete(@NonNull Task<AuthResult> task) {
                           if(task.isSuccessful()){
                               Student information=new Student(fullName,LastName, Username, Email, phonenumber,gender);
                               databaseReference.push().setValue(information);
                                 FirebaseDatabase.getInstance().getReference("Student").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                     .setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                     @Override
                                     public void onComplete(@NonNull Task<Void> task) {
                                         Toast.makeText(Signupffff.this, "Account created", Toast.LENGTH_SHORT).show();

                                         Intent intent = new Intent(Signupffff.this, MainActivity.class);
                                         startActivity(intent);
                                     }

                                    
                                 });
                           }
                           else
                           {
                               Toast.makeText(Signupffff.this, "Account not created", Toast.LENGTH_SHORT).show();
                           }
                       }


                });
                }


          });

            }



}
















