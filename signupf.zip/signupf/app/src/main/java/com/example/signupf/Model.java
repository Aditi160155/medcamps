package com.example.signupf;

public class Model {
    String Hospitalname;
    String contact;
    String email;
    static String pimage;

    Model(){

    }
    public Model(String hospitalname, String contact, String email, String pimage) {
        Hospitalname = hospitalname;
        this.contact = contact;
        this.email = email;
        this.pimage = pimage;
    }

    public String getHospitalname() {
        return Hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        Hospitalname = hospitalname;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public static String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }
}
