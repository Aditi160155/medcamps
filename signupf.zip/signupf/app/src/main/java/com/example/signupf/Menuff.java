package com.example.signupf;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.LOGIN.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Menuff extends AppCompatActivity {
    ProgressDialog progressDialog;
    RecyclerView mRecyclerView;
    EditText txt_Search;
    ImageButton maps;
    ImageButton share;
    TextView text;
    FirebaseAuth firebaseAuth;

    List<FoodData> myFoodList;
    FoodData mFoodData;
    FirebaseDatabase database;

    private DatabaseReference databaseReference;


    private ValueEventListener eventListener;
    MyAdapter myAdapter;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuff);
        text=findViewById(R.id.text);
        firebaseAuth=FirebaseAuth.getInstance();
        FirebaseUser user=firebaseAuth.getCurrentUser();
        text.setText("Hi   "+user.getEmail());

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);


        GridLayoutManager gridLayoutManager = new GridLayoutManager(Menuff.this, 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);







        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading posts....");



        myFoodList = new ArrayList<>();




        myAdapter = new MyAdapter(Menuff.this,myFoodList);
        mRecyclerView.setAdapter(myAdapter);
        databaseReference = FirebaseDatabase.getInstance().getReference("Recipe");
        progressDialog.show();



        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {




                myFoodList.clear();

                for(DataSnapshot itemSnapshot: snapshot.getChildren()) {

                    FoodData foodData = itemSnapshot.getValue(FoodData.class);
                    foodData.setKey(itemSnapshot.getKey());
                    myFoodList.add(foodData);



                }
                myAdapter.notifyDataSetChanged();
                progressDialog.dismiss();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
            }


        });
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);


        gridLayoutManager = new GridLayoutManager(Menuff.this, 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);




        txt_Search = (EditText) findViewById(R.id.txt_searchtext);
        maps = (ImageButton) findViewById(R.id.maps);
        share = (ImageButton) findViewById(R.id.share);


        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading items....");



        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {


            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.hospital:
                        startActivity(new Intent(getApplicationContext(), About.class));
                        Toast.makeText(getApplicationContext(), "Hospital Details", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.notifications:
                        startActivity(new Intent(getApplicationContext(), DashBoard.class));
                        Toast.makeText(getApplicationContext(), "Notifications", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.document:
                        startActivity(new Intent(getApplicationContext(), Document.class));
                        Toast.makeText(getApplicationContext(), "Documents", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.account:
                        startActivity(new Intent(getApplicationContext(), Account.class));
                        Toast.makeText(getApplicationContext(), "Account", Toast.LENGTH_SHORT).show();
                        break;
                }
                return true;
            }

        });

    }

    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuff.class));
        finish();
    }

    public void map1(View view) {
        Intent intent = new Intent(Menuff.this, Maps.class);
        startActivity(intent);
    }
}

