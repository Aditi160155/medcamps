package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

public class Share extends AppCompatActivity {

    private Button b1;
    private Button b6;
    private Button b8;
    String uriString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        b1 =(Button)findViewById(R.id.button5);
        b6 =(Button)findViewById(R.id.button6);
        b8=(Button)findViewById(R.id.button7);



            b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(Intent.ACTION_SEND);
                ii.setType("text/plain");
                uriString="https://www.transparenthands.org/importance-and-objectives-of-the-free-medical-camp/";
                ii.putExtra(Intent.EXTRA_TEXT,uriString);
                ii.setPackage("com.whatsapp");
                startActivity(ii);
            }
            });
        b6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(Intent.ACTION_SEND);
                i2.setType("text/plain");
                uriString="https://www.transparenthands.org/importance-and-objectives-of-the-free-medical-camp/";
                i2.putExtra(Intent.EXTRA_TEXT,uriString);
                i2.setPackage("com.facebook.katana");
                startActivity(i2);
            }
        });
        b8.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i3 = new Intent(Intent.ACTION_SEND);
                i3.setType("text/plain");
                uriString="https://www.transparenthands.org/importance-and-objectives-of-the-free-medical-camp/";
                i3.putExtra(Intent.EXTRA_TEXT,uriString);
                i3.setPackage("com.instagram.android");
                startActivity(i3);
            }
        });

    }
}






