package com.example.signupf;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.LOGIN.R;

public class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewholder> {
    private String[] data;

    public Adapter( String[] data){
        this.data =data;
    }
    @NonNull
    @Override
    public AdapterViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());
        View view =inflater.inflate(R.layout.layout,parent,false);
        return new AdapterViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewholder holder, int position) {
        String title =data[position];
        holder.texttitle.setText(title);

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class AdapterViewholder extends RecyclerView.ViewHolder{
        ImageView imgicon;
        TextView texttitle;

        public AdapterViewholder(@NonNull View itemView) {
            super(itemView);
            imgicon= (ImageView)   itemView.findViewById(R.id.imgicon);
            texttitle=(TextView)   itemView.findViewById(R.id.texttitle);
        }
    }
}
