package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

public class Firstpage extends AppCompatActivity {
    Button b1;
    Button b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);
        b1 = (Button) findViewById(R.id.org);
        b2 = (Button) findViewById(R.id.user);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Firstpage.this, Loginorg.class);
                startActivity(intent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Firstpage.this, MainActivity.class);
                startActivity(intent1);
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
        System.exit(0);
        finish();
    }
}

