package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

public class Menuorg extends AppCompatActivity {
    ImageView img1,img2,img3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuorg);
     //   iv1=(ImageView)findViewById(R.id.imageView3);
       // iv2=(ImageView)findViewById(R.id.imageView2);
     //   home1=(ImageView)findViewById(R.id.imageView12);
        img1=(ImageView)findViewById(R.id.text_view_show_uploads);
        img2=findViewById(R.id.text_view_show_upload3);
        img3=findViewById(R.id.btn1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menuorg.this,Recyclerviewhey.class);
                startActivity(intent);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(Menuorg.this,Accountorg.class);
                startActivity(intent2);
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(Menuorg.this,Upload_Recipe.class);
                startActivity(intent3);
            }
        });
    }
    }


