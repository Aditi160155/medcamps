package com.example.signupf;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.Calendar;

public class DashBoard extends AppCompatActivity  implements View.OnClickListener {
    private int notificationId = 1;

    public static final String CHANNEL_ID = "simplified coding";
    public static final String CHANNEL_NAME = "simplified coding";
    private static final String CHANNEL_DESC = "simplified coding notifications";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_na);
        bottomNavigationView.setSelectedItemId(R.id.notifications);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.home:
                    startActivity(new Intent(getApplicationContext(), Menuff.class));
                    Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.hospital:
                    startActivity(new Intent(getApplicationContext(), About.class));
                    Toast.makeText(getApplicationContext(), "Hospital Details", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.notifications:
                    Toast.makeText(getApplicationContext(), "Notifications", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.document:
                    startActivity(new Intent(getApplicationContext(), Document.class));
                    Toast.makeText(getApplicationContext(), "Documents", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.account:
                    startActivity(new Intent(getApplicationContext(), Account.class));
                    Toast.makeText(getApplicationContext(), "Account", Toast.LENGTH_SHORT).show();
                    break;
            }
            return true;
        }

        });

    }







        public void onClick(View view) {

            EditText editText = findViewById(R.id.editText);
            TimePicker timePicker = findViewById(R.id.timePicker);

            // Intent
            Intent intent = new Intent(DashBoard.this, AlarmReceiver.class);
            intent.putExtra("notificationId", notificationId);
            intent.putExtra("message", editText.getText().toString());

            // PendingIntent
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    DashBoard.this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT
            );

            // AlarmManager
            AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);

            switch (view.getId()) {
                case R.id.setBtn:
                    int hour = timePicker.getCurrentHour();
                    int minute = timePicker.getCurrentMinute();

                    // Create time.
                    Calendar startTime = Calendar.getInstance();
                    startTime.set(Calendar.HOUR_OF_DAY, hour);
                    startTime.set(Calendar.MINUTE, minute);
                    startTime.set(Calendar.SECOND, 0);
                    long alarmStartTime = startTime.getTimeInMillis();

                    // Set Alarm
                    alarmManager.set(AlarmManager.RTC_WAKEUP, alarmStartTime, pendingIntent);
                    Toast.makeText(this, "Done!", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.cancelBtn:
                    alarmManager.cancel(pendingIntent);
                    Toast.makeText(this, "Cancelled.", Toast.LENGTH_SHORT).show();
                    break;
            }


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(CHANNEL_DESC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }


        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel channel=
                    new NotificationChannel("MyNotifications","MyNotifications", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager=getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        FirebaseMessaging.getInstance().subscribeToTopic("general")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        String msg = "Successfull";
                        if (!task.isSuccessful()) {
                            msg = "failed";
                        }
                        Toast.makeText(DashBoard.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });



    }
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuff.class));
        finish();
    }


}



