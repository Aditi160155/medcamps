package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.LOGIN.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ShowPosts extends AppCompatActivity {
    RecyclerView mRecyclerView;
    EditText txt_Search;
    FirebaseAuth firebaseAuth;

    List<FoodData> myFoodList;
    FoodData mFoodData;
    FirebaseDatabase database;

    private DatabaseReference databaseReference;


    private ValueEventListener eventListener;
    MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_posts);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);


        GridLayoutManager gridLayoutManager = new GridLayoutManager(ShowPosts.this, 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);


        myFoodList = new ArrayList<>();


        myAdapter = new MyAdapter(ShowPosts.this, myFoodList);
        mRecyclerView.setAdapter(myAdapter);
        databaseReference = FirebaseDatabase.getInstance().getReference("Recipe");


        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                myFoodList.clear();

                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {

                    FoodData foodData = itemSnapshot.getValue(FoodData.class);
                    foodData.setKey(itemSnapshot.getKey());
                    myFoodList.add(foodData);


                }
                myAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);


        gridLayoutManager = new GridLayoutManager(ShowPosts.this, 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);


        txt_Search = (EditText) findViewById(R.id.txt_searchtext);
    }
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuorg.class));
        finish();
    }

}