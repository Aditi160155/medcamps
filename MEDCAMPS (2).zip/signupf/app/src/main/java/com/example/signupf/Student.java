package com.example.signupf;

public class Student {
    public String fullName;
    public String LastName;
    public static String Username;
    public String Email;
    public String Phonenumber;
    public String Gender;


    public Student(String registrationno, String hospitalName, String email, String phonenumber) {

    }


    public static String getUsername() {

        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public Student(String fullName, String lastName, String username, String email, String phonenumber, String gender) {
        this.fullName = fullName;
        LastName = lastName;
        Username = username;
        Email = email;
        Phonenumber = phonenumber;
        Gender=gender;


    }
}