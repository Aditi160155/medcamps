package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Document extends AppCompatActivity {
    FloatingActionButton f1;
    Button showuploads;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document);
       BottomNavigationView bottomNavigationView = findViewById(R.id.nav1);
        bottomNavigationView.setSelectedItemId(R.id.document);
        f1=findViewById(R.id.idfabEmail);
        showuploads=findViewById(R.id.showuploads);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {


            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(), Menuff.class));
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.hospital:
                        startActivity(new Intent(getApplicationContext(), About.class));
                        Toast.makeText(getApplicationContext(), "Hospital Details", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.notifications:
                        startActivity(new Intent(getApplicationContext(), DashBoard.class));
                        Toast.makeText(getApplicationContext(), "Notifications", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.document:
                        Toast.makeText(getApplicationContext(), "Documents", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.account:
                        startActivity(new Intent(getApplicationContext(), Account.class));
                        Toast.makeText(getApplicationContext(), "Account", Toast.LENGTH_SHORT).show();
                        break;
                }
                return true;
            }

        });

        f1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent int11=new Intent(Document.this,Mainactivity1.class);
                startActivity(int11);

            }
        });
        showuploads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openImagesActivity();

            }
        });
    }




     private void openImagesActivity() {
        Intent intent = new Intent(this, Imagesactivity.class);
        startActivity(intent);
    }
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuff.class));
        finish();
    }

}




