package com.example.signupf;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hsalf.smilerating.SmileRating;

public class History extends AppCompatActivity {
    private SmileRating mRatingBar;
    private DatabaseReference mRatingBarCh;
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        SmileRating smileRating = (SmileRating) findViewById(R.id.ratingBar);
        button = (Button) findViewById(R.id.button);
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference mRatingBarCh = rootRef.child("ratings");


        smileRating.setOnRatingSelectedListener(new SmileRating.OnRatingSelectedListener() {
            @Override
            public void onRatingSelected(int level, boolean reselected) {
                Toast.makeText(getApplicationContext(), "Your feedback value is " + level,
                        Toast.LENGTH_SHORT).show();
                mRatingBarCh.child("rating").setValue(String.valueOf(level));

                // reselected is false when user selects different smiley that previously selected one
                // true when the same smiley is selected.
                // Except if it first time, then the value will be false.
            }
        });

    }
}




