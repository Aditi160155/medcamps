package com.example.signupf;

public class Membera {
    private String Gender;

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public Membera()
    {

    }
}
