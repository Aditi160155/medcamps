package com.example.signupf;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class Accountorg extends AppCompatActivity {
    Button log;
    Button hel;
    Button his;
    StorageReference storageReference;
    FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private TextView textView1;
    FirebaseAuth firebaseAuth;
    Button changeProfile;
    CircleImageView profileImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountorg);
        log=(Button)findViewById(R.id.logout);
        hel=(Button)findViewById(R.id.help1);
        his=(Button)findViewById(R.id.historyy);
        textView1 = findViewById(R.id.textView1);
        profileImage=findViewById(R.id.imageView23);

        changeProfile=findViewById(R.id.changeProfile);

        firebaseAuth = FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        DatabaseReference databaseReference=database.getReference(Objects.requireNonNull(firebaseAuth.getUid()));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataholder user=snapshot.getValue(dataholder.class);
                if (user != null) {
                    textView1.setText(user.getHospitalname());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(),"Database Error",Toast.LENGTH_SHORT).show();
            }
        });
        if (firebaseAuth.getCurrentUser() == null) {
            finish();
            startActivity(new Intent(this, MainActivity.class));
        }


        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1=new Intent(Accountorg.this,Loginorg.class);
                startActivity(int1);
            }
        });
        hel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2=new Intent(Accountorg.this,Helporg.class);
                startActivity(int2);
            }
        });
        his.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int3=new Intent(Accountorg.this,Historyorg.class);
                startActivity(int3);
            }
        });
        changeProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openGalleryIntent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(openGalleryIntent,1000);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1000){
            if(resultCode== Activity.RESULT_OK){
                Uri imageuri=data.getData();
                profileImage.setImageURI(imageuri);
                uploadImageToFirebase(imageuri);

            }
        }
    }

    private void uploadImageToFirebase(Uri imageuri) {
        final StorageReference fileRef=storageReference.child("Huser/"+firebaseAuth.getCurrentUser().getUid()+"/profile.jpg");
        StorageTask<UploadTask.TaskSnapshot> failed = fileRef.putFile(imageuri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.get().load(uri).into(profileImage);
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Accountorg.this, "FAILED", Toast.LENGTH_SHORT).show();
            }
        });




    }
    public void onBackPressed () {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuorg.class));
        finish();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu men) {
        getMenuInflater().inflate(R.menu.menu, men);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()){
            case R.id.uploads:{
                startActivity(new Intent(Accountorg.this,ShowPosts.class));
                break;
            }

            default:
                Toast.makeText(Accountorg.this, "nothing is selected", Toast.LENGTH_SHORT).show();
             //   throw new IllegalStateException("Unexpected value: " + item.getItemId());
        }
        return super.onOptionsItemSelected(item);
    }
}

    


