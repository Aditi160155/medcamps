package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.LOGIN.R;

public class  Help extends AppCompatActivity {
private Button b1;
private Button b2;
private Button b3;
private Button b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        b1 = (Button) findViewById(R.id.button11);
        b2 = (Button) findViewById(R.id.button1);
        b3 = (Button) findViewById(R.id.button2);
        b4= (Button) findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent int111=new Intent(Help.this,Buttonone.class);
                startActivity(int111);

            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent int222=new Intent(Help.this,Buttontwo.class);
                startActivity(int222);

            }
        });
        b3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent int333=new Intent(Help.this,Buttonthree.class);
                startActivity(int333);

            }
        });
        b4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent int444=new Intent(Help.this,Buttonfour.class);
                startActivity(int444);

            }
        });

    }}