package com.example.signupf;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.LOGIN.R;

public class Abo extends AppCompatActivity {
    RecyclerView recview;
    HaAdapter adapter;
    TextView hey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abo);


    }


    }



