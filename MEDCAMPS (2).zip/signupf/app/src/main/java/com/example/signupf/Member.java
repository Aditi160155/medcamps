package com.example.signupf;

public class Member {
    private String  spinner;

    public String getSpinner() {
        return spinner;
    }

    public void setSpinner(String spinner) {
        this.spinner = spinner;
    }

    public Member(){

    }
}
