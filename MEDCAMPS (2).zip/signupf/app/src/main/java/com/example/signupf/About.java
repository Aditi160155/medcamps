package com.example.signupf;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.LOGIN.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class About extends AppCompatActivity {
    private TextView view1;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private ImageView imageView;
    ImageButton img1;
    RecyclerView recview;
    HaAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        recview=(RecyclerView)findViewById(R.id.recview);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nb);
        bottomNavigationView.setSelectedItemId(R.id.hospital);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {


            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.hospital:
                        startActivity(new Intent(getApplicationContext(), About.class));
                        Toast.makeText(getApplicationContext(), "Hospital Details", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.notifications:
                        startActivity(new Intent(getApplicationContext(), DashBoard.class));
                        Toast.makeText(getApplicationContext(), "Notifications", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.document:
                        startActivity(new Intent(getApplicationContext(), Document.class));
                        Toast.makeText(getApplicationContext(), "Documents", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.account:
                        startActivity(new Intent(getApplicationContext(), Account.class));
                        Toast.makeText(getApplicationContext(), "Account", Toast.LENGTH_SHORT).show();
                        break;
                }
                return true;
            }

        });
        recview.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<Model> options =
                new FirebaseRecyclerOptions.Builder<Model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("users"), Model.class)
                        .build();

        adapter=new HaAdapter(options,getApplicationContext()) ;
        recview.setAdapter(adapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), Menuff.class));
        finish();
    }


}







