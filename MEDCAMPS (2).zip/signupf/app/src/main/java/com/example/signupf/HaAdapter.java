package com.example.signupf;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.LOGIN.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import de.hdodenhof.circleimageview.CircleImageView;

public class HaAdapter  extends FirebaseRecyclerAdapter <Model,HaAdapter.myviewholder>
{

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     * @param applicationContext
     */
    public HaAdapter(@NonNull FirebaseRecyclerOptions<Model> options, Context applicationContext) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull Model model)
    {
        holder.Hospitalname.setText(model.getHospitalname());
        holder.contact.setText(model.getContact());
        holder.email.setText(model.getEmail());
        Glide.with(holder.img.getContext()).load(Model.getPimage()).into(holder.img);
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder
    {
        CircleImageView img;
        TextView Hospitalname,contact,email;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            img=(CircleImageView) itemView.findViewById(R.id.img1);
            Hospitalname=(TextView)itemView.findViewById(R.id.nametext);
            contact=(TextView)itemView.findViewById(R.id.contact);
            email=(TextView)itemView.findViewById(R.id.emailtext);
        }
    }
}


