package com.example.signupf;

public class HospitalUsers {

    public String Registrationno;

    public  static String HospitalName;
    public String Email;
    public String Phonenumber;


    public HospitalUsers() {

    }


    public HospitalUsers(String registrationno, String hospitalName,String email, String phonenumber) {
        Registrationno = registrationno;
        HospitalName=hospitalName;
        Email = email;
        Phonenumber = phonenumber;
    }

    public static String getHospitalName() {
        return HospitalName;
    }

    public static void setHospitalName(String hospitalName) {
        HospitalName = hospitalName;
    }

}









